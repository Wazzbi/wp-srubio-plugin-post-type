<?php
/*
Plugin Name: srubio post_types
Plugin URI:
Description: Adding Custom Post Types for srubio
Version: 1.2
Author: David Novotny
Author URI:
License:
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: srubio-post_types
Domain Path: /languages
*/

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

include_once('includes/product-post-type.php');
// include_once('includes/product-category-tax.php');
// include_once('includes/product-brand-tax.php');
include_once('includes/enqueue-assets.php');
include_once('includes/utility-functions.php');


function srubio_post_types_activate()
{
    srubio_post_types_setup_post_type();
    // srubio_post_types_register_product_category_tax();
    // srubio_post_types_register_product_brand_tax();
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, 'srubio_post_types_activate');

function srubio_post_types_deactivate()
{
    unregister_post_type('srubio_product');
    // unregister_taxonomy('srubio_product_category');
    // unregister_taxonomy('srubio_product_brand');
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, 'srubio_post_types_deactivate');
