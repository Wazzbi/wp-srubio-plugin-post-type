<?php

/**
 * ===========================================
 * 1. Register the Custom Taxonomy: Product Brand
 * ===========================================
 */
function optic_post_types_register_product_brand_tax()
{
    // Define the labels for the Brand taxonomy
    $labels = array(
        'name'                       => esc_html_x('Brands', 'Taxonomy General Name', 'optic-post_types'),
        'singular_name'              => esc_html_x('Brand', 'Taxonomy Singular Name', 'optic-post_types'),
        'menu_name'                  => esc_html__('Brands', 'optic-post_types'),
        'all_items'                  => esc_html__('All Brands', 'optic-post_types'),
        'edit_item'                  => esc_html__('Edit Brand', 'optic-post_types'),
        'view_item'                  => esc_html__('View Brand', 'optic-post_types'),
        'update_item'                => esc_html__('Update Brand', 'optic-post_types'),
        'add_new_item'               => esc_html__('Add New Brand', 'optic-post_types'),
        'new_item_name'              => esc_html__('New Brand Name', 'optic-post_types'),
        'parent_item'                => null, // Not used for non-hierarchical
        'parent_item_colon'          => null, // Not used for non-hierarchical
        'search_items'               => esc_html__('Search Brands', 'optic-post_types'),
        // These labels are typical for non-hierarchical (tag-like) taxonomies
        'popular_items'              => esc_html__('Popular Brands', 'optic-post_types'),
        'separate_items_with_commas' => esc_html__('Separate brands with commas', 'optic-post_types'),
        'add_or_remove_items'        => esc_html__('Add or remove brands', 'optic-post_types'),
        'choose_from_most_used'      => esc_html__('Choose from the most used brands', 'optic-post_types'),
        'not_found'                  => esc_html__('No Brands Found', 'optic-post_types'),
        'no_terms'                   => esc_html__('No brands', 'optic-post_types'),
        'items_list'                 => esc_html__('Brands list', 'optic-post_types'),
        'items_list_navigation'      => esc_html__('Brands list navigation', 'optic-post_types'),
    );

    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false, // Key difference: Brands are not nested
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        // Using 'brand' as the slug for cleaner URLs
        'rewrite'                    => array('slug' => 'brand', 'hierarchical' => false),
    );

    // Register the taxonomy, linking it to the custom post type 'optic_product'
    register_taxonomy('optic_product_brand', ['optic_product'], $args);
};

add_action('init', 'optic_post_types_register_product_brand_tax');

// -----------------------------------------------------------------------------

/**
 * ===========================================
 * 2. Term Meta Fields (Image) for Brands
 * (For "Brand Logo" on the Admin Taxonomy screens)
 * ===========================================
 */

/*
 * Add a new field to the 'Add New' form (wp-admin/edit-tags.php?taxonomy=optic_product_brand)
 */
function optic_product_brand_add_form_fields()
{
    // The HTML is identical to your categories, just with brand-specific labels
?>
    <div class="form-field term-image-wrap">
        <label for="term_image_id"><?php esc_html_e('Brand Logo', 'optic-post_types'); ?></label>
        <input type="hidden" id="term_image_id" name="term_image_id" value="">
        <div id="term_image_preview"></div>
        <p>
            <a href="#" class="button upload_image_button"><?php esc_html_e('Upload/Add Image', 'optic-post_types'); ?></a>
            <a href="#" class="button remove_image_button" style="display:none;"><?php esc_html_e('Remove Image', 'optic-post_types'); ?></a>
        </p>
    </div>
<?php
}
add_action('optic_product_brand_add_form_fields', 'optic_product_brand_add_form_fields');

/*
 * Add a new field to the 'Edit' form (wp-admin/term.php?taxonomy=optic_product_brand)
 */
function optic_product_brand_edit_form_fields($term)
{
    $image_id = get_term_meta($term->term_id, 'term_image_id', true);
    $image_url = $image_id ? wp_get_attachment_url($image_id) : '';
?>
    <tr class="form-field term-image-wrap">
        <th scope="row"><label for="term_image_id"><?php esc_html_e('Brand Logo', 'optic-post_types'); ?></label></th>
        <td>
            <input type="hidden" id="term_image_id" name="term_image_id" value="<?php echo esc_attr($image_id); ?>">
            <div id="term_image_preview">
                <?php if ($image_url) { ?>
                    <img src="<?php echo esc_url($image_url); ?>" alt="" style="max-width:150px; height:auto;">
                <?php } ?>
            </div>
            <p>
                <a href="#" class="button upload_image_button"><?php esc_html_e('Upload/Add Image', 'optic-post_types'); ?></a>
                <a href="#" class="button remove_image_button" style="<?php echo $image_url ? '' : 'display:none;'; ?>"><?php esc_html_e('Remove Image', 'optic-post_types'); ?></a>
            </p>
        </td>
    </tr>
<?php
}
add_action('optic_product_brand_edit_form_fields', 'optic_product_brand_edit_form_fields');

/*
 * Save the image ID when a term is created or edited.
 */
function optic_save_product_brand_image($term_id)
{
    if (isset($_POST['term_image_id'])) {
        $image_id = absint($_POST['term_image_id']);
        // Use the same meta key 'term_image_id' for consistency
        update_term_meta($term_id, 'term_image_id', $image_id);
    }
}
add_action('created_optic_product_brand', 'optic_save_product_brand_image');
add_action('edited_optic_product_brand', 'optic_save_product_brand_image');

// -----------------------------------------------------------------------------

/**
 * ===========================================
 * 3. Admin Columns for Brands
 * ===========================================
 */

// Add 'Logo' column to the Brands list screen
function optic_add_brand_image_column($columns)
{
    $new_columns = array();
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        if ($key === 'name') {
            // New column slug and title
            $new_columns['optic_product_brand_image'] = esc_html__('Logo', 'optic-post_types');
        }
    }
    return $new_columns;
}
add_filter('manage_edit-optic_product_brand_columns', 'optic_add_brand_image_column');

// Populate the 'Logo' column for Brands
function optic_show_brand_image_column($content, $column_name, $term_id)
{
    if ('optic_product_brand_image' === $column_name) {
        $image_id = get_term_meta($term_id, 'term_image_id', true);
        if ($image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'thumbnail');
            if ($image_url) {
                $content = '<img src="' . esc_url($image_url) . '" alt="" style="max-width: 50px; height: auto;" />';
            }
        }
    }
    return $content;
}
// Note the filter name uses 'manage_{taxonomy_slug}_custom_column'
add_action('manage_optic_product_brand_custom_column', 'optic_show_brand_image_column', 10, 3);

// -----------------------------------------------------------------------------

/**
 * ===========================================
 * 4. Enqueue Scripts for Admin UI
 * (Updating your existing function to include the new taxonomy)
 * ===========================================
 */
// Modify your existing enqueue function to also target the new brand taxonomy screen
function optic_enqueue_taxonomy_scripts($hook)
{
    // Check if we are on the taxonomy edit screen (or post edit screen, which is already handled in your original code)
    if ('edit-tags.php' !== $hook && 'term.php' !== $hook) {
        return;
    }

    // Check if the current taxonomy is either the category or the brand
    if (isset($_GET['taxonomy']) && in_array($_GET['taxonomy'], ['optic_product_category', 'optic_product_brand'])) {
        wp_enqueue_media();
        // The script path is the same as the one you provided in the original code
        wp_enqueue_script('custom-taxonomy-image', plugin_dir_url(__FILE__) . '../dist/assets/js/taxonomy-image.js', array('jquery'), null, true);
    }
}
// If this function is already defined in your code (as it was in the original), you only need to update the logic inside it.
// I've included the updated function above.