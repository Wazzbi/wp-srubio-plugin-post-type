<?php
function wp-optic_post_types_register_skills_tax()
{
    $labels = array(
        'name' => esc_html_x('Skills', 'taxonomy general name', '_wp-optic-pluginname'),
        'singular_name' => esc_html_x('Skill', 'taxonomy singular name', '_wp-optic-pluginname'),
        'search_items' => esc_html__('Search Skills', '_wp-optic-pluginname'),
        'all_items' => esc_html__('All Skills', '_wp-optic-pluginname'),
        'parent_item' => esc_html__('Parent Skill', '_wp-optic-pluginname'),
        'parent_item_colon' => esc_html__('Parent Skill:', '_wp-optic-pluginname'),
        'edit_item' => esc_html__('Edit Skill', '_wp-optic-pluginname'),
        'update_item' => esc_html__('Update Skill', '_wp-optic-pluginname'),
        'add_new_item' => esc_html__('Add New Skill', '_wp-optic-pluginname'),
        'new_item_name' => esc_html__('New Skill Name', '_wp-optic-pluginname'),
        'menu_name' => esc_html__('Skills', '_wp-optic-pluginname'),
    );
    $args = array(
        'hierarchical' => false,
        'show_admin_column' => true,
        'labels' => $labels,
        'rewrite' => ['slug' => 'skills']
    );
    register_taxonomy('wp-optic_skills', ['wp-optic_portfolio'], $args);
};

add_action('init', 'wp-optic_post_types_register_skills_tax');
