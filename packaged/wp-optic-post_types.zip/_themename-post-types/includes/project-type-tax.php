<?php
function wp-optic_post_types_register_project_type_tax()
{
    $labels = array(
        'name' => esc_html_x('Project Type', 'taxonomy general name', 'wp-optic-post_types'),
        'singular_name' => esc_html_x('Project Type', 'taxonomy singular name', 'wp-optic-post_types'),
        'search_items' => esc_html__('Search Project Types', 'wp-optic-post_types'),
        'all_items' => esc_html__('All Project Types', 'wp-optic-post_types'),
        'parent_item' => esc_html__('Parent Project Type', 'wp-optic-post_types'),
        'parent_item_colon' => esc_html__('Parent Project Type:', 'wp-optic-post_types'),
        'edit_item' => esc_html__('Edit Project Type', 'wp-optic-post_types'),
        'update_item' => esc_html__('Update Project Type', 'wp-optic-post_types'),
        'add_new_item' => esc_html__('Add New Project Type', 'wp-optic-post_types'),
        'new_item_name' => esc_html__('New Project Type Name', 'wp-optic-post_types'),
        'menu_name' => esc_html__('Project Types', 'wp-optic-post_types')
    );
    $args = array(
        'hierarchical' => true,
        'show_admin_column' => true,
        'labels' => $labels,
        'rewrite' => array('slug' => 'project_type')
    );
    register_taxonomy('wp-optic_project_type', ['wp-optic_portfolio'], $args);
};

add_action('init', 'wp-optic_post_types_register_project_type_tax');
