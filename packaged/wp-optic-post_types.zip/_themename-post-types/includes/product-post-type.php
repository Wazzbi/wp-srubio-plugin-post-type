<?php
function wp-optic_post_types_setup_post_type()
{
    $labels = array(
        'name' => esc_html_x('Products', 'Post type general name', 'wp-optic-post_types'),
        'singular_name' => esc_html_x('Product', 'Post type singular name', 'wp-optic-post_types'),
        'menu_name' => esc_html_x('Products', 'Admin Menu text', 'wp-optic-post_types'),
        'name_admin_bar' => esc_html_x('Product', 'Add New on Toolbar', 'wp-optic-post_types'),
        'add_new' => esc_html__('Add New', 'wp-optic-post_types'),
        'add_new_item' => esc_html__('Add New Product', 'wp-optic-post_types'),
        'new_item' => esc_html__('New Product', 'wp-optic-post_types'),
        'edit_item' => esc_html__('Edit Product', 'wp-optic-post_types'),
        'view_item' => esc_html__('View Product', 'wp-optic-post_types'),
        'view_items' => esc_html__('View Products', 'wp-optic-post_types'),
        'all_items' => esc_html__('All Products', 'wp-optic-post_types'),
        'search_items' => esc_html__('Search Products', 'wp-optic-post_types'),
        'parent_item_colon' => esc_html__('Parent Products:', 'wp-optic-post_types'),
        'not_found' => esc_html__('No Products found.', 'wp-optic-post_types'),
        'not_found_in_trash' => esc_html__('No Products found in Trash.', 'wp-optic-post_types'),
        'featured_image' => esc_html_x('Product Image', 'Overrides the "Featured Image" phrase for this post type. Added in 4.3', 'wp-optic-post_types'),
        'set_featured_image' => esc_html_x('Set product image', 'Overrides the "Set featured image" phrase for this post type. Added in 4.3', 'wp-optic-post_types'),
        'remove_featured_image' => esc_html_x('Remove product image', 'Overrides the "Remove featured image" phrase for this post type. Added in 4.3', 'wp-optic-post_types'),
        'use_featured_image' => esc_html_x('Use as product image', 'Overrides the "Use as featured image" phrase for this post type. Added in 4.3', 'wp-optic-post_types'),
        'archives' => esc_html_x('Product archives', 'The post type archive label used in nav menus. Default "Post Archives". Added in 4.4.', 'wp-optic-post_types'),
        'insert_into_item' => esc_html_x('Insert into product', 'Overrides the "Insert into post"/"Insert into page" phrase (used when inserting media into a post). Added in 4.4.', 'wp-optic-post_types'),
        'uploaded_to_this_item' => esc_html_x('Uploaded to this product', 'Overrides the "Uploaded to this post"/"Uploaded to this page" phrase (used when viewing media attached to a post). Added in 4.4.', 'wp-optic-post_types'),
        'filter_items_list' => esc_html_x('Filter product list', 'Screen reader text for the filter links heading on the post type listing screen. Default "Filter posts list"/"Filter pages list". Added in 4.4.', 'wp-optic-post_types'),
        'items_list_navigation' => esc_html_x('Product list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default "Posts list navigation"/"Pages list navigation". Added in 4.4.', 'wp-optic-post_types'),
        'items_list' => esc_html_x('Product list', 'Screen reader text for the items list heading on the post type listing screen. Default "Posts list"/"Pages list". Added in 4.4.', 'wp-optic-post_types'),
    );

    register_post_type('wp-optic_product', array(
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-cart',
        'labels' => $labels,
        'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'rewrite' => array('slug' => 'products')
    ));
};
add_action('init', 'wp-optic_post_types_setup_post_type');
